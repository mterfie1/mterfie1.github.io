<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

	<title>Form Handleing</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

</head>
	<body>

		<?php
			$title = $_POST["title"];
			$fname = $_POST["fname"];
			$lname = $_POST["lname"];
			$address = $_POST["address"];
			$year = $POST["year"]
			
			$currentYear = 2017;
			
			$age = $currentYear - $year;
			
	
	
	
	
			<p>print("Hello, " . $title . " " . $lname . " " . $fname . " of " . $address . ".");</p>
			<p>print("You will be " . $age . " this year.");</p>
	




?>
	</body>
</html>

