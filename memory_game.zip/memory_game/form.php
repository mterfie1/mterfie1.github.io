<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

	<title>Form Handleing</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

</head>
	<body>

		<?php
			
			
			if (isset($_POST['heman']) && isset($_POST['heman2'])) {
 				
				header("Location: memory6.html");
			
			}
			
			else if (isset($_POST['batman']) && isset($_POST['batman2'])) {
				
				header("Location: memory6.html");
			}
			
			else if (isset($_POST['superman']) && isset($_POST['superman2'])) {
				
				header("Location: memory6.html");
			}
			
			else if (isset($_POST['wonderwoman']) && isset($_POST['wonderwoman2'])) {
				
				header("Location: memory6.html");
			}
			
			else if (isset($_POST['spiderman']) && isset($_POST['spiderman2'])) {
				
				header("Location: memory6.html");
			}
			
			else if (isset($_POST['ironman']) && isset($_POST['ironman2'])) {
				
				header("Location: memory6.html");
			}
			
			else if (isset($_POST['hulk']) && isset($_POST['hulk2'])) {
				
				header("Location: memory6.html");
			}
			
			else if (isset($_POST['wolverine']) && isset($_POST['wolverine2'])) {
				
				header("Location: memory6.html");
			}
			
			else if (isset($_POST['deadpool']) && isset($_POST['deadpool2'])) {
				
				header("Location: memory6.html");
			}
			
			else{
				
			
				header("Location: memory7.html");
				
				
				
			}
			
			
			
	
		?>
	
		


		

	</body>
</html>