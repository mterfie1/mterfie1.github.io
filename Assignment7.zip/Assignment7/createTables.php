<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<style>
body {
    background-color: #F5F5DC;

}

.align {
    display: inline-block;
    clear: left;
    width: 230px;
    text-align: right;
}
h2 {
    display: inline-block;
    clear: left;
    width: 230px;
    text-align: center;

}
table { 
  width: 70px; 
  border-collapse: collapse; 


}

tr:nth-of-type(odd) { 
  background: #eee; 
}

th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
#table_container{
    margin-top:-258px;
    margin-left:300px;
}
#table_container2{
    margin-top:10px;
    margin-left:300px;
	
}

</style>
<title>mySQL conn</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>

<?php


$mysql_host="localhost";
$mysql_user="mterfie1";
$mysql_password="mterfie1";

$con = mysql_connect($mysql_host,$mysql_user,$mysql_password);

if (!$con){
	die("Error: " . mysql_error());
}
echo "Mysql connection successful" . "<br/>";

$db = mysql_select_db("mterfie1",$con);

if (!$db){
	echo "Error: " . mysql_error();
}
else{
	echo "Database connection successful" . "<br/>";	
}

$table1 = "CREATE TABLE albums (

	title varchar(20),
	artist varchar(20),
	year int(4),
	genre varchar(20)

)";

$table2 = "CREATE TABLE artists (

	name varchar(20),
	bio varchar(20),
	albums varchar(40)

)";

$sql = mysql_query($table1,$con);
$sql2 = mysql_query($table2,$con);


if (!$sql){
}
else{
	echo "Table1 created successfully" . "<br/>";	
}
if (!$sql2){
}
else{
	echo "Table2 created successfully" . "<br/>";	
}



?>
<form action="createTables.php" method="post">
	<div class="align">
	<h2>Albums</h2>
	<br/>
        <label>Title:</label> <input type="text" name="title"><br/>
	<label>Artist:</label> <input type="text" name="artist"><br/>
	<label>Year:</label> <input type="text" name="year"><br/>
	<label>Genre:</label> <input type="text" name="genre"><br/>
	<input type="submit" name="submitAlbum">
	<h2>Artists</h2>
	<br/>
	<label>Name:</label> <input type="text" name="name"><br/>
	<label>Bio:</label> <input type="text" name="bio"><br/>
	<label>Album:</label> <input type="text" name="albums"><br/>
	<input type="submit" name="submitArtist">
	</div>
<?php
 
if (isset($_POST['submitAlbum'])){
	
	$album = "INSERT INTO albums (title,artist,year,genre) VALUES ('$_POST[title]','$_POST[artist]','$_POST[year]','$_POST[genre]')";
	
	mysql_query($album,$con);
	
	
	
}

else if (isset($_POST['submitArtist'])){
	
	$artist = "INSERT INTO artists (name,bio,albums) VALUES ('$_POST[name]','$_POST[bio]','$_POST[albums]')";
	
	mysql_query($artist,$con);
	
	
}

else {

}

?>

<div id="table_container">
<table>
	<thead>
	<tr>
		<th>Album#</th>
		<th>Title</th>
		<th>Artitst</th>
		<th>Year</th>
		<th>Genre</th>

	</tr>
	</thead>
	<tbody>
	<?php
		$i = 0;
		$tb1 = "SELECT * FROM albums";
		$result = mysql_query($tb1,$con);

		
				while($row = mysql_fetch_array($result)) : $i++; ?>
					
					
					<tr>
		
						<td><?php echo $i ?></td>
						<td><?php echo $row['title']?></td>
						<td><?php echo $row['artist']?></td>
						<td><?php echo $row['year']?></td>
						<td><?php echo $row['genre']?></td>
					</tr>
					
					
				
			
				
			<?php endwhile ?>
	</tbody>		
</table>
</div>
<div id="table_container2">
<table>
	<thead>
	<tr>
		<th>Artist#</th>
		<th>Name</th>
		<th>Biography</th>
		<th>Albums</th>

	</tr>
	</thead>
	<tbody>
	<?php
		$j = 0;
		$tb2 = "SELECT * FROM artists";
		$result2 = mysql_query($tb2,$con);

		
				while($row2 = mysql_fetch_array($result2)) : $j++; ?>
					
					
					<tr>
		
						<td><?php echo $j ?></td>
						<td><?php echo $row2['name']?></td>
						<td><?php echo $row2['bio']?></td>
						<td><?php echo $row2['albums']?></td>
					</tr>
					
					
				
			
				
			<?php endwhile ?>
	</tbody>		
</table>
</div>
</body>
</html>
